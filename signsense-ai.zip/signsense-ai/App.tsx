import React from 'react';
import { ActivityIndicator, SafeAreaView, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import HomeScreen from './src/screens/HomeScreen';
import SubscriptionScreen from './src/screens/SubscriptionScreen';
import AuthScreen from './src/screens/AuthScreen';
import { useAuth } from './src/hooks/useAuth';
import { useSubscription } from './src/hooks/useSubscription';
import { COLORS } from './src/config/constants';

export default function App() {
  const { uid, isLoading: authLoading } = useAuth();
  const { isLoading: subLoading, hasAccess } = useSubscription();

  const isLoading = authLoading || (Boolean(uid) && subLoading);

  if (isLoading) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <StatusBar style="light" />
        <ActivityIndicator color={COLORS.accent} size="large" />
      </SafeAreaView>
    );
  }

  return (
    <>
      <StatusBar style="light" />
      {!uid ? (
        <AuthScreen />
      ) : hasAccess ? (
        <HomeScreen />
      ) : (
        <SubscriptionScreen />
      )}
    </>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    backgroundColor: COLORS.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
