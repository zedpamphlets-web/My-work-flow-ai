export type SupportedLanguage =
  | 'english'
  | 'bemba'
  | 'nyanja'
  | 'tonga'
  | 'lozi'
  | 'kaonde'
  | 'lunda'
  | 'luvale';

export interface SignPrediction {
  signId: string;
  label: string;
  confidence: number;
  timestamp: number;
}

export interface BufferedSentence {
  text: string;
  words: string[];
  language: SupportedLanguage;
  signIds: string[];
  createdAt: number;
}
