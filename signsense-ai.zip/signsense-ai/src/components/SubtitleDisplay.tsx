import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { COLORS } from '../config/constants';

interface Props {
  text: string;
  placeholder: string;
}

export default function SubtitleDisplay({ text, placeholder }: Props) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>{text || placeholder}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    minHeight: 80,
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 12,
    backgroundColor: COLORS.panel,
    padding: 16,
    justifyContent: 'center',
  },
  text: {
    color: COLORS.textPrimary,
    fontSize: 16,
    textAlign: 'center',
  },
});
