import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Camera } from 'react-native-vision-camera';
import { useCamera } from '../hooks/useCamera';
import { COLORS } from '../config/constants';

interface Props {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  frameProcessor?: any;
}

/**
 * Renders the live camera feed used for sign recognition. Handles
 * permission and "no device found" states gracefully so the rest of
 * the app doesn't need to worry about them. Optionally attaches a
 * frame processor for real-time hand tracking.
 */
export default function CameraView({ frameProcessor }: Props) {
  const { device, hasPermission, isRequesting } = useCamera();

  if (isRequesting) {
    return (
      <View style={styles.messageContainer}>
        <Text style={styles.messageText}>Requesting camera access…</Text>
      </View>
    );
  }

  if (!hasPermission) {
    return (
      <View style={styles.messageContainer}>
        <Text style={styles.messageText}>
          Camera access is required for sign recognition.
        </Text>
      </View>
    );
  }

  if (!device) {
    return (
      <View style={styles.messageContainer}>
        <Text style={styles.messageText}>No camera device found.</Text>
      </View>
    );
  }

  return (
    <Camera
      style={StyleSheet.absoluteFill}
      device={device}
      isActive={true}
      video={false}
      audio={false}
      frameProcessor={frameProcessor}
    />
  );
}

const styles = StyleSheet.create({
  messageContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  messageText: {
    color: COLORS.textSecondary,
    fontSize: 14,
    textAlign: 'center',
  },
});
