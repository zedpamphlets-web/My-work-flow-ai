import React from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity } from 'react-native';
import type { SupportedLanguage } from '../types';
import { SUPPORTED_LANGUAGES, COLORS } from '../config/constants';

interface Props {
  selected: SupportedLanguage;
  onSelect: (language: SupportedLanguage) => void;
}

const LABELS: Record<SupportedLanguage, string> = {
  english: 'English',
  bemba: 'Bemba',
  nyanja: 'Nyanja',
  tonga: 'Tonga',
  lozi: 'Lozi',
  kaonde: 'Kaonde',
  lunda: 'Lunda',
  luvale: 'Luvale',
};

export default function LanguageSelector({ selected, onSelect }: Props) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.container}>
      {SUPPORTED_LANGUAGES.map((lang) => {
        const isActive = lang === selected;
        return (
          <TouchableOpacity
            key={lang}
            style={[styles.chip, isActive && styles.chipActive]}
            onPress={() => onSelect(lang)}
          >
            <Text style={[styles.chipText, isActive && styles.chipTextActive]}>
              {LABELS[lang]}
            </Text>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 0,
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: COLORS.panel,
    marginRight: 8,
  },
  chipActive: {
    backgroundColor: COLORS.accent,
  },
  chipText: {
    color: COLORS.textSecondary,
    fontSize: 13,
  },
  chipTextActive: {
    color: COLORS.textPrimary,
    fontWeight: '600',
  },
});
