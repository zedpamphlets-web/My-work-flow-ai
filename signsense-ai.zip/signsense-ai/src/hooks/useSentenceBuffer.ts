import { useEffect, useRef, useState } from 'react';
import type { SignPrediction, SupportedLanguage, BufferedSentence } from '../types';
import { getVocabularyEntry } from '../lib/recognition/vocabulary';
import { SENTENCE_PAUSE_MS } from '../config/constants';

/**
 * Buffers a stream of individual sign predictions into a sentence.
 * When no new sign has been recognized for SENTENCE_PAUSE_MS, the
 * buffered sentence is considered "finished" and returned via
 * onSentenceComplete, then the buffer resets — enabling automatic,
 * hands-free speech output with no button press required.
 */
export function useSentenceBuffer(
  prediction: SignPrediction | null,
  language: SupportedLanguage,
  onSentenceComplete: (sentence: BufferedSentence) => void
) {
  const [bufferedText, setBufferedText] = useState('');
  const signIdsRef = useRef<string[]>([]);
  const wordsRef = useRef<string[]>([]);
  const pauseTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastSignIdRef = useRef<string | null>(null);

  useEffect(() => {
    if (!prediction) return;
    if (prediction.signId === lastSignIdRef.current) return; // avoid duplicate consecutive signs

    lastSignIdRef.current = prediction.signId;
    const entry = getVocabularyEntry(prediction.signId);
    if (!entry) return;

    const word = entry.translations[language];
    wordsRef.current.push(word);
    signIdsRef.current.push(prediction.signId);
    setBufferedText(wordsRef.current.join(' '));

    if (pauseTimer.current) clearTimeout(pauseTimer.current);
    pauseTimer.current = setTimeout(() => {
      if (wordsRef.current.length > 0) {
        onSentenceComplete({
          text: wordsRef.current.join(' '),
          words: [...wordsRef.current],
          language,
          signIds: [...signIdsRef.current],
          createdAt: Date.now(),
        });
      }
      wordsRef.current = [];
      signIdsRef.current = [];
      lastSignIdRef.current = null;
      setBufferedText('');
    }, SENTENCE_PAUSE_MS);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prediction, language]);

  return { bufferedText };
}
