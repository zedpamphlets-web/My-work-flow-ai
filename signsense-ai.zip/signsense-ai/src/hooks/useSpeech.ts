import { useCallback } from 'react';
import type { BufferedSentence } from '../types';
import { speak, stopSpeaking } from '../lib/speech/ttsEngine';

/**
 * Speaks completed sentences automatically as they arrive from the
 * sentence buffer — no button press required, matching the app's
 * hands-free design goal.
 */
export function useSpeech() {
  const speakSentence = useCallback((sentence: BufferedSentence) => {
    speak(sentence.text, sentence.language);
  }, []);

  const stop = useCallback(() => {
    stopSpeaking();
  }, []);

  return { speakSentence, stop };
}
