import { useCallback, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { firestore } from '../lib/firebase/firebaseConfig';
import { useAuth } from './useAuth';
import type { PlanId } from '../config/pricing';
import { getPlan } from '../config/pricing';

const CACHE_KEY_PREFIX = 'signsense.subscriptionCache.';

interface SubscriptionDoc {
  trialStartedAt: number;
  accessExpiresAt: number;
}

interface SubscriptionState {
  isLoading: boolean;
  hasAccess: boolean;
  isTrialActive: boolean;
  daysRemaining: number;
  activatePlan: (planId: PlanId) => Promise<void>;
}

/**
 * Tracks trial + paid access per real (anonymously-authenticated)
 * Firebase user, stored in Firestore under users/{uid}. A local
 * AsyncStorage cache is used so the app still works offline and
 * shows the last-known status while Firestore syncs in the
 * background — consistent with the app needing to work offline.
 *
 * Because this now lives server-side under a real Firebase UID
 * (rather than only on-device), it survives app reinstalls as long
 * as the same anonymous session persists, and is no longer as easily
 * reset as pure local storage was.
 *
 * Firestore setup required: enable Anonymous auth (Authentication →
 * Sign-in method → Anonymous) and create a Firestore database in your
 * Firebase console. Suggested security rule so each user can only
 * read/write their own record:
 *
 *   match /users/{userId} {
 *     allow read, write: if request.auth != null && request.auth.uid == userId;
 *   }
 */
export function useSubscription(): SubscriptionState {
  const { uid, isLoading: authLoading } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [expiresAt, setExpiresAt] = useState<number | null>(null);
  const [isTrialActive, setIsTrialActive] = useState(false);

  useEffect(() => {
    if (authLoading || !uid) return;

    (async () => {
      const cacheKey = `${CACHE_KEY_PREFIX}${uid}`;
      let docData: SubscriptionDoc | null = null;

      // Try Firestore first (source of truth); fall back to local cache
      // if offline, so the app still works without internet.
      try {
        const snap = await getDoc(doc(firestore, 'users', uid));
        if (snap.exists()) {
          docData = snap.data() as SubscriptionDoc;
        }
      } catch {
        const cached = await AsyncStorage.getItem(cacheKey);
        if (cached) docData = JSON.parse(cached);
      }

      let trialStartedAt = docData?.trialStartedAt ?? null;

      if (!trialStartedAt) {
        // First-ever session for this user: start the free trial.
        trialStartedAt = Date.now();
        const newDoc: SubscriptionDoc = { trialStartedAt, accessExpiresAt: 0 };
        docData = newDoc;
        await AsyncStorage.setItem(cacheKey, JSON.stringify(newDoc));
        try {
          await setDoc(doc(firestore, 'users', uid), newDoc);
        } catch {
          // Offline on first launch — local cache above still holds it;
          // will sync to Firestore next time there's connectivity via
          // activatePlan() or a future read/write.
        }
      }

      const trialPlan = getPlan('trial');
      const trialExpiry = trialStartedAt + trialPlan.durationDays * 24 * 60 * 60 * 1000;
      const storedExpiry = docData?.accessExpiresAt ?? 0;
      const effectiveExpiry = Math.max(trialExpiry, storedExpiry);

      setExpiresAt(effectiveExpiry);
      setIsTrialActive(Date.now() < trialExpiry && storedExpiry < trialExpiry);
      setIsLoading(false);
    })();
  }, [uid, authLoading]);

  const activatePlan = useCallback(
    async (planId: PlanId) => {
      if (!uid) return;

      const plan = getPlan(planId);
      const now = Date.now();
      const cacheKey = `${CACHE_KEY_PREFIX}${uid}`;

      let currentExpiry = 0;
      try {
        const snap = await getDoc(doc(firestore, 'users', uid));
        if (snap.exists()) currentExpiry = (snap.data() as SubscriptionDoc).accessExpiresAt ?? 0;
      } catch {
        const cached = await AsyncStorage.getItem(cacheKey);
        if (cached) currentExpiry = (JSON.parse(cached) as SubscriptionDoc).accessExpiresAt ?? 0;
      }

      const base = Math.max(now, currentExpiry);
      const newExpiry = base + plan.durationDays * 24 * 60 * 60 * 1000;

      const cached = await AsyncStorage.getItem(cacheKey);
      const trialStartedAt = cached ? (JSON.parse(cached) as SubscriptionDoc).trialStartedAt : now;
      const updatedDoc: SubscriptionDoc = { trialStartedAt, accessExpiresAt: newExpiry };

      await AsyncStorage.setItem(cacheKey, JSON.stringify(updatedDoc));
      await setDoc(doc(firestore, 'users', uid), updatedDoc);

      setExpiresAt(newExpiry);
      setIsTrialActive(false);
    },
    [uid]
  );

  const hasAccess = expiresAt !== null && Date.now() < expiresAt;
  const daysRemaining = expiresAt
    ? Math.max(0, Math.ceil((expiresAt - Date.now()) / (24 * 60 * 60 * 1000)))
    : 0;

  return {
    isLoading: authLoading || isLoading,
    hasAccess,
    isTrialActive,
    daysRemaining,
    activatePlan,
  };
}
