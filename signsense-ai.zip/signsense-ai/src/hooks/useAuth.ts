import { useCallback, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  type User,
} from 'firebase/auth';
import { firebaseAuth } from '../lib/firebase/firebaseConfig';

interface UseAuthResult {
  uid: string | null;
  email: string | null;
  isLoading: boolean;
  error: string | null;
  signUp: (email: string, password: string) => Promise<boolean>;
  signIn: (email: string, password: string) => Promise<boolean>;
  signOut: () => Promise<void>;
}

/**
 * Real Firebase email/password accounts — sign-up is now required to
 * use the app (per updated requirements). This replaces the earlier
 * anonymous-auth approach.
 *
 * No automatic sign-in happens here: until the user submits the
 * sign-up or log-in form via signUp()/signIn(), uid stays null and
 * App.tsx shows the AuthScreen.
 */
export function useAuth(): UseAuthResult {
  const [uid, setUid] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(firebaseAuth, (user: User | null) => {
      setUid(user?.uid ?? null);
      setEmail(user?.email ?? null);
      setIsLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const signUp = useCallback(async (emailInput: string, password: string) => {
    setError(null);
    try {
      await createUserWithEmailAndPassword(firebaseAuth, emailInput.trim(), password);
      return true;
    } catch (err: any) {
      setError(mapFirebaseError(err?.code));
      return false;
    }
  }, []);

  const signIn = useCallback(async (emailInput: string, password: string) => {
    setError(null);
    try {
      await signInWithEmailAndPassword(firebaseAuth, emailInput.trim(), password);
      return true;
    } catch (err: any) {
      setError(mapFirebaseError(err?.code));
      return false;
    }
  }, []);

  const signOut = useCallback(async () => {
    await firebaseSignOut(firebaseAuth);
  }, []);

  return { uid, email, isLoading, error, signUp, signIn, signOut };
}

function mapFirebaseError(code?: string): string {
  switch (code) {
    case 'auth/email-already-in-use':
      return 'An account with this email already exists — try logging in instead.';
    case 'auth/invalid-email':
      return 'That email address looks invalid.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters.';
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Incorrect email or password.';
    default:
      return 'Something went wrong. Please try again.';
  }
}
