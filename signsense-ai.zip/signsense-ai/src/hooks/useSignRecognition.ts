import { useEffect, useRef, useState } from 'react';
import type { TrackingResult } from '../lib/tracking/trackerInterface';
import type { SignPrediction } from '../types';
import { SignRecognitionModel } from '../lib/recognition/model';

const FRAME_WINDOW_SIZE = 16;

/**
 * Feeds a rolling window of tracking frames into the recognition model
 * and surfaces the latest confident sign prediction, if any.
 */
export function useSignRecognition(latestResult: TrackingResult | null) {
  const modelRef = useRef<SignRecognitionModel>(new SignRecognitionModel());
  const windowRef = useRef<TrackingResult[]>([]);
  const [prediction, setPrediction] = useState<SignPrediction | null>(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    modelRef.current.initialize().then(() => setIsReady(true));
    return () => modelRef.current.dispose();
  }, []);

  useEffect(() => {
    if (!isReady || !latestResult) return;

    windowRef.current.push(latestResult);
    if (windowRef.current.length > FRAME_WINDOW_SIZE) {
      windowRef.current.shift();
    }

    const result = modelRef.current.predict(windowRef.current);
    if (result) {
      setPrediction(result);
    }
  }, [latestResult, isReady]);

  return { prediction, isReady };
}
