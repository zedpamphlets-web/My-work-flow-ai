import { useCallback, useState } from 'react';
import type { BufferedSentence } from '../types';
import { smoothSentence } from '../lib/ai/sentenceSmoothing';
import { useNetworkStatus } from './useNetworkStatus';

interface SmoothingResult {
  finalText: string;
  wasSmoothed: boolean;
  showOfflineNotice: boolean;
}

/**
 * Attempts AI sentence smoothing when online; falls back to the raw
 * word-by-word text when offline or if the AI call fails, and surfaces
 * a one-shot "smoothing needs internet" notice so the UI can inform
 * the user without blocking speech output — the app must still work
 * offline, just with unsmoothed grammar.
 */
export function useSentenceSmoothing() {
  const { isOnline } = useNetworkStatus();
  const [offlineNoticeVisible, setOfflineNoticeVisible] = useState(false);

  const process = useCallback(
    async (sentence: BufferedSentence): Promise<SmoothingResult> => {
      if (!isOnline) {
        setOfflineNoticeVisible(true);
        return { finalText: sentence.text, wasSmoothed: false, showOfflineNotice: true };
      }

      try {
        const smoothed = await smoothSentence(sentence.words, sentence.language);
        setOfflineNoticeVisible(false);
        return { finalText: smoothed, wasSmoothed: true, showOfflineNotice: false };
      } catch {
        // AI call failed (bad key, network hiccup, etc.) — fall back
        // gracefully rather than blocking speech output.
        setOfflineNoticeVisible(true);
        return { finalText: sentence.text, wasSmoothed: false, showOfflineNotice: true };
      }
    },
    [isOnline]
  );

  return { process, offlineNoticeVisible };
}
