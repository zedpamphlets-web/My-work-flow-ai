import { useTensorflowModel } from 'react-native-fast-tflite';
import { useResizePlugin } from 'vision-camera-resize-plugin';
import { useFrameProcessor } from 'react-native-vision-camera';
import { useCallback, useRef, useState } from 'react';
import { runOnJS } from 'react-native-reanimated';
import type { TrackingResult, HandLandmarks, Landmark } from '../lib/tracking/trackerInterface';

/**
 * Real, working hand-tracking pipeline using ONLY pre-built,
 * already-compiled native libraries — react-native-fast-tflite
 * (runs a .tflite model on-device) and vision-camera-resize-plugin
 * (converts camera frames to the model's input format). Neither
 * requires writing or compiling custom native Kotlin/Swift code,
 * which makes this achievable without a native mobile developer or
 * Android Studio/Xcode — only `npx expo prebuild` + EAS Build (cloud)
 * or `expo run:android` are needed.
 *
 * MODEL: assets/models/hand_landmark_full.tflite — download from
 * https://storage.googleapis.com/mediapipe-assets/hand_landmark_full.tflite
 * (Google's own official model asset bucket — this is the real
 * standalone TFLite hand-landmark regressor MediaPipe itself uses).
 *
 * ⚠️ HONEST LIMITATION: a full MediaPipe-quality pipeline normally
 * runs a palm DETECTOR first to crop a tight box around the hand,
 * then runs the landmark model on that crop. MediaPipe's official
 * palm_detection.tflite uses custom TFLite ops that generic runtimes
 * (including react-native-fast-tflite) cannot load — this is a real,
 * documented limitation, not something fixable in this file. So this
 * implementation resizes the CENTER of the full camera frame directly
 * into the landmark model. This works well when the hand is roughly
 * centered and reasonably close to the camera — which fits this
 * app's use case (holding the phone up close while signing) — but
 * will be less robust than a full detector+landmark pipeline,
 * especially if the hand is off-center or far from the camera.
 *
 * ⚠️ VERIFY INPUT SIZE: this uses 224x224 as the model's expected
 * input based on the model's documented architecture, but you should
 * confirm the exact input tensor shape by opening the downloaded
 * .tflite file at https://netron.app before relying on this — if it
 * differs, update MODEL_INPUT_SIZE below to match.
 */

const MODEL_INPUT_SIZE = 224;
const MIN_HAND_PRESENCE_SCORE = 0.5;

export function useHandTracking() {
  const model = useTensorflowModel(require('../../assets/models/hand_landmark_full.tflite'));
  const { resize } = useResizePlugin();

  const [latestResult, setLatestResult] = useState<TrackingResult | null>(null);
  const resultRef = useRef<TrackingResult | null>(null);

  const handleResult = useCallback((result: TrackingResult) => {
    resultRef.current = result;
    setLatestResult(result);
  }, []);

  const tfliteModel = model.state === 'loaded' ? model.model : undefined;

  const frameProcessor = useFrameProcessor(
    (frame) => {
      'worklet';
      if (tfliteModel == null) return;

      // Center-crop to a square, then resize to the model's input size.
      // See the ⚠️ note above on why this replaces a palm detector.
      const cropSize = Math.min(frame.width, frame.height);
      const resized = resize(frame, {
        scale: { width: MODEL_INPUT_SIZE, height: MODEL_INPUT_SIZE },
        crop: {
          x: (frame.width - cropSize) / 2,
          y: (frame.height - cropSize) / 2,
          width: cropSize,
          height: cropSize,
        },
        pixelFormat: 'rgb',
        dataType: 'float32',
      });

      const outputs = tfliteModel.runSync([resized]);

      // Standard hand_landmark model output order: [landmarks(63),
      // hand_presence_score(1), handedness(1)]. Verify against your
      // downloaded model in Netron — adjust indices if different.
      const rawLandmarks = outputs[0] as number[];
      const presenceScore = (outputs[1]?.[0] as number) ?? 0;
      const handednessScore = (outputs[2]?.[0] as number) ?? 0.5;

      if (presenceScore < MIN_HAND_PRESENCE_SCORE || rawLandmarks.length < 63) {
        runOnJS(handleResult)({ hands: [], timestamp: Date.now() });
        return;
      }

      const landmarks: Landmark[] = [];
      for (let i = 0; i < 63; i += 3) {
        landmarks.push({
          x: rawLandmarks[i] / MODEL_INPUT_SIZE,
          y: rawLandmarks[i + 1] / MODEL_INPUT_SIZE,
          z: rawLandmarks[i + 2],
        });
      }

      const hand: HandLandmarks = {
        handedness: handednessScore > 0.5 ? 'Right' : 'Left',
        landmarks,
        confidence: presenceScore,
      };

      runOnJS(handleResult)({ hands: [hand], timestamp: Date.now() });
    },
    [tfliteModel]
  );

  return {
    frameProcessor,
    latestResult,
    resultRef,
    isModelReady: model.state === 'loaded',
    modelError: model.state === 'error' ? model.error : null,
  };
}
