import type { SupportedLanguage } from '../../types';

/**
 * Initial small sign vocabulary. Each entry maps a signId (used internally
 * and by the recognition model's output classes) to its English label plus
 * translations in all 8 supported languages.
 *
 * This starter set covers common greeting/basic-need signs — enough to
 * validate the end-to-end pipeline before scaling up vocabulary size.
 */
export interface VocabularyEntry {
  signId: string;
  translations: Record<SupportedLanguage, string>;
}

export const VOCABULARY: VocabularyEntry[] = [
  {
    signId: 'hello',
    translations: {
      english: 'Hello',
      bemba: 'Muli shani',
      nyanja: 'Muli bwanji',
      tonga: 'Mwabuka buti',
      lozi: 'Mu shwile',
      kaonde: 'Mwabuka byepi',
      lunda: 'Mwabuka nahi',
      luvale: 'Mwapoka ngachilihi',
    },
  },
  {
    signId: 'thank_you',
    translations: {
      english: 'Thank you',
      bemba: 'Natotela',
      nyanja: 'Zikomo',
      tonga: 'Twalumba',
      lozi: 'Ni itumezi',
      kaonde: 'Natotela',
      lunda: 'Nasakwilili',
      luvale: 'Ngasakwilila',
    },
  },
  {
    signId: 'yes',
    translations: {
      english: 'Yes',
      bemba: 'Ee',
      nyanja: 'Inde',
      tonga: 'Iyi',
      lozi: 'Ee',
      kaonde: 'Ee',
      lunda: 'Eeña',
      luvale: 'Eyo',
    },
  },
  {
    signId: 'no',
    translations: {
      english: 'No',
      bemba: 'Awe',
      nyanja: 'Iyayi',
      tonga: 'Pe',
      lozi: 'Batili',
      kaonde: 'Ne',
      lunda: 'Nehi',
      luvale: 'Nehi',
    },
  },
  {
    signId: 'help',
    translations: {
      english: 'Help',
      bemba: 'Nafwaya ukwaafwa',
      nyanja: 'Ndithandizeni',
      tonga: 'Ndigwasye',
      lozi: 'Ni tuse',
      kaonde: 'Ngwashai',
      lunda: 'Nkwashi',
      luvale: 'Ngukafwa',
    },
  },
];

export function getVocabularyEntry(signId: string): VocabularyEntry | undefined {
  return VOCABULARY.find((v) => v.signId === signId);
}
