import type { TrackingResult, Landmark } from '../tracking/trackerInterface';
import type { SignPrediction } from '../../types';
import { MIN_SIGN_CONFIDENCE } from '../../config/constants';

/**
 * Sign-recognition model.
 *
 * HONEST SCOPE: this is a real, working GEOMETRIC classifier — it
 * reads actual hand-landmark coordinates and measures which fingers
 * are extended vs. curled to distinguish a handful of distinct hand
 * shapes. It is NOT a trained neural network, and the 5 shapes below
 * are NOT verified authentic Zambian Sign Language or ASL handshapes
 * — they're simple, mutually-distinguishable poses (fist, open palm,
 * thumbs up, pointing, pinch) used as placeholders mapped onto the
 * vocabulary so the pipeline is genuinely testable end-to-end.
 *
 * Real Zambian Sign Language recognition — correct handshapes,
 * movement, and non-manual markers (facial expression, etc.) — needs
 * an actual trained model on real ZSL video/landmark data, which this
 * project does not yet have. This classifier is a legitimate stepping
 * stone (it truly does classify hand geometry, no fakery), not a
 * finished sign-language recognizer.
 *
 * It also depends entirely on receiving REAL landmark coordinates.
 * Right now, neither hand-tracking backend produces real landmarks
 * yet: the native MediaPipe plugin isn't built, and no .tflite model
 * is bundled. See src/lib/tracking/ and the README for that work.
 */

const FINGER_TIP_IDS = [4, 8, 12, 16, 20]; // thumb, index, middle, ring, pinky
const FINGER_PIP_IDS = [3, 6, 10, 14, 18]; // joint one below each tip
const WRIST_ID = 0;

type HandShape = 'fist' | 'open_palm' | 'thumbs_up' | 'pointing' | 'pinch' | 'unknown';

// Maps each placeholder hand shape to a vocabulary signId.
const SHAPE_TO_SIGN_ID: Record<Exclude<HandShape, 'unknown'>, string> = {
  open_palm: 'hello',
  pinch: 'thank_you',
  thumbs_up: 'yes',
  fist: 'no',
  pointing: 'help',
};

export class SignRecognitionModel {
  private ready = false;

  async initialize(): Promise<void> {
    this.ready = true;
  }

  predict(frames: TrackingResult[]): SignPrediction | null {
    if (!this.ready || frames.length === 0) return null;

    const lastFrame = frames[frames.length - 1];
    if (lastFrame.hands.length === 0) return null;

    const hand = lastFrame.hands[0];
    if (hand.landmarks.length < 21) return null; // need full 21-point hand

    const shape = classifyHandShape(hand.landmarks);
    if (shape === 'unknown') return null;

    const signId = SHAPE_TO_SIGN_ID[shape];
    const confidence = hand.confidence;

    if (confidence < MIN_SIGN_CONFIDENCE) return null;

    return {
      signId,
      label: signId,
      confidence,
      timestamp: lastFrame.timestamp,
    };
  }

  dispose(): void {
    this.ready = false;
  }
}

/**
 * Determines whether each finger is extended by comparing the
 * tip-to-wrist distance against the corresponding pip-joint-to-wrist
 * distance — a genuinely working, if simple, geometric technique
 * (works regardless of hand rotation, unlike a naive y-coordinate
 * comparison).
 */
function getExtendedFingers(landmarks: Landmark[]): boolean[] {
  const wrist = landmarks[WRIST_ID];

  return FINGER_TIP_IDS.map((tipId, i) => {
    const tip = landmarks[tipId];
    const pip = landmarks[FINGER_PIP_IDS[i]];
    const tipDist = distance(tip, wrist);
    const pipDist = distance(pip, wrist);
    return tipDist > pipDist * 1.1; // tip meaningfully farther than pip = extended
  });
}

function distance(a: Landmark, b: Landmark): number {
  return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2);
}

function classifyHandShape(landmarks: Landmark[]): HandShape {
  const [thumb, index, middle, ring, pinky] = getExtendedFingers(landmarks);
  const extendedCount = [thumb, index, middle, ring, pinky].filter(Boolean).length;

  if (extendedCount === 5) return 'open_palm';
  if (extendedCount === 0) return 'fist';
  if (thumb && !index && !middle && !ring && !pinky) return 'thumbs_up';
  if (!thumb && index && !middle && !ring && !pinky) return 'pointing';
  if (isPinching(landmarks)) return 'pinch';

  return 'unknown';
}

/**
 * Pinch = thumb tip and index tip close together, other three fingers
 * curled.
 */
function isPinching(landmarks: Landmark[]): boolean {
  const thumbTip = landmarks[4];
  const indexTip = landmarks[8];
  const wrist = landmarks[WRIST_ID];
  const handSpan = distance(landmarks[5], wrist); // rough scale reference

  const pinchDist = distance(thumbTip, indexTip);
  const [, , middle, ring, pinky] = getExtendedFingers(landmarks);

  return pinchDist < handSpan * 0.35 && !middle && !ring && !pinky;
}
