export interface Landmark {
  x: number;
  y: number;
  z: number;
}

export interface HandLandmarks {
  handedness: 'Left' | 'Right';
  landmarks: Landmark[];
  confidence: number;
}

export interface TrackingResult {
  hands: HandLandmarks[];
  timestamp: number;
}

/**
 * Shared contract any hand-tracking backend must implement, whether
 * powered by MediaPipe (vision-camera frame processor) or TensorFlow Lite.
 * Keeps the rest of the app agnostic to which backend is active.
 */
export interface HandTracker {
  readonly name: string;
  initialize(): Promise<void>;
  processFrame(frameData: unknown): TrackingResult;
  dispose(): void;
}
