import { initializeApp, getApps, getApp } from 'firebase/app';
import { initializeAuth, getReactNativePersistence, getAuth } from 'firebase/auth';
// eslint-disable-next-line @typescript-eslint/no-var-requires
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getFirestore } from 'firebase/firestore';

/**
 * Firebase setup for SignSense AI.
 *
 * NOTE ON ANALYTICS: firebase/analytics (getAnalytics) relies on
 * browser-only APIs and does NOT work in React Native. It's
 * intentionally left out here. If you want app analytics later, use
 * @react-native-firebase/analytics instead (a separate native module),
 * or a RN-friendly analytics tool (e.g. Expo's own analytics, or
 * PostHog/Amplitude).
 *
 * These values are the standard Firebase *client* config — they're
 * meant to be public (they identify your project, not authenticate
 * as an admin), so it's fine for them to live directly in the app
 * bundle. Actual data access is protected by Firestore security
 * rules, not by hiding this config.
 */
const firebaseConfig = {
  apiKey: 'AIzaSyBTeUHeJqm0WX2UamOWWSi1Yd3zRt1IKvI',
  authDomain: 'interschool-8d764.firebaseapp.com',
  projectId: 'interschool-8d764',
  storageBucket: 'interschool-8d764.firebasestorage.app',
  messagingSenderId: '634054060868',
  appId: '1:634054060868:web:76f258b93885230e1c4511',
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

// initializeAuth (not getAuth) is required on first call in React Native
// so we can wire up AsyncStorage persistence — otherwise the user would
// be signed out and re-anonymized every app restart.
let auth;
try {
  auth = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage),
  });
} catch {
  // initializeAuth throws if already called once (e.g. fast refresh
  // during development) — fall back to the existing instance.
  auth = getAuth(app);
}

export const firebaseAuth = auth;
export const firestore = getFirestore(app);
export default app;
