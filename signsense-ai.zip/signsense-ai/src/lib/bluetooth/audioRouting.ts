/**
 * Bluetooth audio routing helper.
 *
 * On both Android and iOS, once a Bluetooth headset/speaker is connected
 * as the system's active audio output, standard TTS playback (expo-speech)
 * routes to it automatically via the OS audio session — no extra code is
 * required for basic playback.
 *
 * This module exists for the cases that DO need explicit handling:
 * detecting whether a Bluetooth output is currently connected (so the UI
 * can show the user "Connected to [device]" for confidence/feedback),
 * and, later, explicit output-device selection if the OS default isn't
 * what the user wants.
 *
 * Implementation here is a light placeholder; a native module
 * (e.g. via react-native-device-info or a small custom native bridge)
 * will be added when we do the native build pass, since Bluetooth device
 * state isn't exposed through pure JS APIs.
 */
export interface AudioOutputStatus {
  isBluetoothConnected: boolean;
  deviceName: string | null;
}

export async function getAudioOutputStatus(): Promise<AudioOutputStatus> {
  // Placeholder until native audio-route detection is wired in.
  return {
    isBluetoothConnected: false,
    deviceName: null,
  };
}
