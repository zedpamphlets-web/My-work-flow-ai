import type { SupportedLanguage } from '../../types';

export const UI_STRINGS: Record<SupportedLanguage, {
  waitingForSign: string;
  cameraPermission: string;
  settings: string;
  language: string;
}> = {
  english: {
    waitingForSign: 'Waiting for a sign…',
    cameraPermission: 'Camera access is required for sign recognition.',
    settings: 'Settings',
    language: 'Language',
  },
  bemba: {
    waitingForSign: 'Nalolela icishibilo…',
    cameraPermission: 'Kamela yalingana pakuti mumfwe icishibilo.',
    settings: 'Ifyakusalapo',
    language: 'Ululimi',
  },
  nyanja: {
    waitingForSign: 'Kudikirira chizindikiro…',
    cameraPermission: 'Kamera ikufunika kuti izindikire zizindikiro.',
    settings: 'Zokonzekera',
    language: 'Chilankhulo',
  },
  tonga: {
    waitingForSign: 'Kulindila chitondezyo…',
    cameraPermission: 'Kamera iyandikana kubona zitondezyo.',
    settings: 'Zibikilo',
    language: 'Mwaambo',
  },
  lozi: {
    waitingForSign: 'Ni libelela sisupo…',
    cameraPermission: 'Kamera i tokwahala kuli ku boniswa lisupo.',
    settings: 'Ze lukisizwe',
    language: 'Puo',
  },
  kaonde: {
    waitingForSign: 'Kupembelela kishishikizho…',
    cameraPermission: 'Kamela yakebewa kumona bishishikizho.',
    settings: 'Bintu bya kukonsha',
    language: 'Mulaka',
  },
  lunda: {
    waitingForSign: 'Kuhembelela chinjikijilu…',
    cameraPermission: 'Kamela yatalisha kumona yinjikijilu.',
    settings: 'Yakutona',
    language: 'Idimi',
  },
  luvale: {
    waitingForSign: 'Kutalilila chinjikizo…',
    cameraPermission: 'Kamela yatalisa kumona vinjikizo.',
    settings: 'Vyakutongola',
    language: 'Lilimi',
  },
};
