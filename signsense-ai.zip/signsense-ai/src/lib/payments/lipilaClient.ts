/**
 * Lipila payment gateway client (Zambia — Airtel Money, MTN MoMo,
 * Zamtel Kwacha, cards).
 *
 * ⚠️ BASE URL NOT YET CONFIRMED: Lipila's REST base URL is shown in
 * your Lipila dashboard after signup, not in their public docs page.
 * Their official Flutter SDK (lipila_flutter) wraps a sandbox and a
 * production base URL selected via LipilaClient.sandbox() /
 * .production(), but I could not verify the literal URL strings from
 * public sources. Log into your Lipila dashboard, find the REST base
 * URL (sandbox and production), and paste them into LIPILA_BASE_URL_*
 * below before this will actually work. Everything else here —
 * request field names, sandbox key prefix "lsk_", production prefix
 * "lpk_", ZMW currency — is confirmed from Lipila's own SDK docs.
 *
 * REQUIRES AN API KEY. Get one from your Lipila dashboard (sandbox
 * keys start with "lsk_", production keys with "lpk_"), then set
 * EXPO_PUBLIC_LIPILA_API_KEY in your .env file (see .env.example).
 *
 * NOTE: as with the Gemini key, an EXPO_PUBLIC_ variable ships inside
 * the app binary. That's a real risk for a *payment* key specifically
 * — before any public release, move payment collection behind a
 * backend you control so this key never reaches end users' devices.
 */

// ⚠️ Replace with the real values from your Lipila dashboard.
const LIPILA_BASE_URL_SANDBOX = 'https://sandbox.lipila.tech'; // placeholder — confirm in dashboard
const LIPILA_BASE_URL_PRODUCTION = 'https://api.lipila.tech'; // placeholder — confirm in dashboard

const API_KEY = process.env.EXPO_PUBLIC_LIPILA_API_KEY;
const IS_SANDBOX = API_KEY?.startsWith('lsk_') ?? true;
const BASE_URL = IS_SANDBOX ? LIPILA_BASE_URL_SANDBOX : LIPILA_BASE_URL_PRODUCTION;

export class LipilaError extends Error {}

export interface CreateCollectionParams {
  referenceId: string;
  amountKwacha: number;
  phoneNumber: string; // Zambian format, e.g. 260977123456
  narration: string;
}

export interface CollectionResult {
  referenceId: string;
  identifier: string;
  status: string;
}

export async function createCollection(
  params: CreateCollectionParams
): Promise<CollectionResult> {
  if (!API_KEY) {
    throw new LipilaError('No Lipila API key configured (EXPO_PUBLIC_LIPILA_API_KEY).');
  }

  const response = await fetch(`${BASE_URL}/collections`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${API_KEY}`,
    },
    body: JSON.stringify({
      referenceId: params.referenceId,
      amount: params.amountKwacha,
      accountNumber: params.phoneNumber,
      currency: 'ZMW',
      narration: params.narration,
    }),
  });

  if (!response.ok) {
    throw new LipilaError(`Lipila collection request failed: ${response.status}`);
  }

  const data = await response.json();
  return {
    referenceId: data.referenceId,
    identifier: data.identifier,
    status: data.status,
  };
}

export async function getCollectionStatus(referenceId: string): Promise<string> {
  if (!API_KEY) {
    throw new LipilaError('No Lipila API key configured (EXPO_PUBLIC_LIPILA_API_KEY).');
  }

  const response = await fetch(`${BASE_URL}/status/${referenceId}`, {
    headers: { Authorization: `Bearer ${API_KEY}` },
  });

  if (!response.ok) {
    throw new LipilaError(`Lipila status check failed: ${response.status}`);
  }

  const data = await response.json();
  return data.status as string;
}
