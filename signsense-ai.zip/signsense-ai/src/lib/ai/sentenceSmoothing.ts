import type { SupportedLanguage } from '../../types';

/**
 * AI-powered sentence smoothing, using the Google Gemini API (free tier).
 *
 * Sign language grammar doesn't map word-for-word onto spoken-language
 * grammar (e.g. raw recognized signs might be "I HELP NEED" instead of
 * "I need help"). This module sends the raw recognized words to Gemini
 * to produce a natural, grammatically correct sentence in the target
 * language before it's spoken aloud.
 *
 * REQUIRES INTERNET. Callers must check useNetworkStatus() and skip
 * calling this (falling back to the raw joined words) when offline —
 * this function does not silently fall back on its own, so failures
 * are visible and callers can show the "smoothing needs internet"
 * message per the app's design.
 *
 * REQUIRES AN API KEY. Get a free key (no credit card) at
 * https://aistudio.google.com/apikey, then set EXPO_PUBLIC_AI_API_KEY
 * in your .env file (see .env.example). Expo automatically inlines
 * EXPO_PUBLIC_-prefixed variables at build time — nothing else to
 * configure.
 *
 * NOTE: an EXPO_PUBLIC_ variable is bundled into the app binary and is
 * NOT a secure place to store a key for a published app (anyone can
 * extract it from the app package). It's fine for development/personal
 * use. Before a public release, this call should be moved behind a
 * small backend proxy you control, so the real key never ships inside
 * the app.
 */

const API_KEY = process.env.EXPO_PUBLIC_AI_API_KEY;
const MODEL = 'gemini-2.5-flash';
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;

export class SmoothingUnavailableError extends Error {}

export async function smoothSentence(
  rawWords: string[],
  language: SupportedLanguage
): Promise<string> {
  if (!API_KEY) {
    throw new SmoothingUnavailableError('No AI API key configured.');
  }
  if (rawWords.length === 0) {
    return '';
  }

  const prompt =
    `Raw signed words in order: "${rawWords.join(' ')}". ` +
    `Rewrite them as a single short, natural, grammatically correct ` +
    `sentence in ${language}. Reply with only the sentence, nothing else.`;

  const response = await fetch(`${API_URL}?key=${API_KEY}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      contents: [
        {
          parts: [{ text: prompt }],
        },
      ],
      generationConfig: {
        maxOutputTokens: 100,
        temperature: 0.3,
      },
    }),
  });

  if (!response.ok) {
    throw new SmoothingUnavailableError(`AI API request failed: ${response.status}`);
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

  if (!text) {
    throw new SmoothingUnavailableError('AI API returned no text.');
  }

  return text;
}
