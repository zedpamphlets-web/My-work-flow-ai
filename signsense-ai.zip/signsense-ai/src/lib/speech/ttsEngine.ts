import * as Speech from 'expo-speech';
import type { SupportedLanguage } from '../../types';

/**
 * Maps our supported languages to BCP-47-ish locale codes expo-speech
 * expects. Where a language isn't natively available on-device, we fall
 * back to a related/default locale — device TTS engines vary widely in
 * which African languages they ship voices for.
 */
const LANGUAGE_LOCALE_MAP: Record<SupportedLanguage, string> = {
  english: 'en-US',
  bemba: 'en-ZM', // fallback until a dedicated Bemba voice is available
  nyanja: 'en-ZM',
  tonga: 'en-ZM',
  lozi: 'en-ZM',
  kaonde: 'en-ZM',
  lunda: 'en-ZM',
  luvale: 'en-ZM',
};

export function speak(text: string, language: SupportedLanguage): void {
  Speech.stop();
  Speech.speak(text, {
    language: LANGUAGE_LOCALE_MAP[language],
    pitch: 1.0,
    rate: 0.95,
  });
}

export function stopSpeaking(): void {
  Speech.stop();
}

export async function isSpeaking(): Promise<boolean> {
  return Speech.isSpeakingAsync();
}
