import React, { useState } from 'react';
import {
  ActivityIndicator,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { SUBSCRIPTION_PLANS, PlanId } from '../config/pricing';
import { createCollection, getCollectionStatus, LipilaError } from '../lib/payments/lipilaClient';
import { useSubscription } from '../hooks/useSubscription';
import { COLORS } from '../config/constants';

const PAYABLE_PLANS = SUBSCRIPTION_PLANS.filter((p) => p.priceKwacha > 0);

type PaymentState = 'idle' | 'awaitingPhoneApproval' | 'success' | 'error';

export default function SubscriptionScreen() {
  const { activatePlan, daysRemaining, isTrialActive } = useSubscription();
  const [selectedPlan, setSelectedPlan] = useState<PlanId>('week');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [paymentState, setPaymentState] = useState<PaymentState>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handlePay = async () => {
    if (!phoneNumber.trim()) {
      setErrorMessage('Enter your mobile money phone number.');
      setPaymentState('error');
      return;
    }

    const plan = PAYABLE_PLANS.find((p) => p.id === selectedPlan)!;
    const referenceId = `SIGNSENSE-${Date.now()}`;

    setPaymentState('awaitingPhoneApproval');
    setErrorMessage('');

    try {
      await createCollection({
        referenceId,
        amountKwacha: plan.priceKwacha,
        phoneNumber: phoneNumber.trim(),
        narration: `SignSense AI - ${plan.label}`,
      });

      // Mobile money collections are approved by the user on their
      // phone (a push prompt), so we poll status rather than getting
      // an instant result.
      const finalStatus = await pollUntilSettled(referenceId);

      if (finalStatus === 'SUCCESSFUL' || finalStatus === 'success') {
        await activatePlan(plan.id);
        setPaymentState('success');
      } else {
        setErrorMessage('Payment was not completed. Please try again.');
        setPaymentState('error');
      }
    } catch (err) {
      const message = err instanceof LipilaError ? err.message : 'Payment failed. Try again.';
      setErrorMessage(message);
      setPaymentState('error');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Continue using SignSense AI</Text>

      {isTrialActive ? (
        <Text style={styles.subtitle}>
          {daysRemaining} day{daysRemaining === 1 ? '' : 's'} left in your free trial.
        </Text>
      ) : (
        <Text style={styles.subtitle}>Choose a plan to keep using the app.</Text>
      )}

      <View style={styles.plansContainer}>
        {PAYABLE_PLANS.map((plan) => {
          const isSelected = plan.id === selectedPlan;
          return (
            <TouchableOpacity
              key={plan.id}
              style={[styles.planCard, isSelected && styles.planCardSelected]}
              onPress={() => setSelectedPlan(plan.id)}
            >
              <Text style={styles.planLabel}>{plan.label}</Text>
              <Text style={styles.planPrice}>K{plan.priceKwacha}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <Text style={styles.inputLabel}>Mobile money phone number</Text>
      <TextInput
        style={styles.input}
        placeholder="0977123456"
        placeholderTextColor={COLORS.textMuted}
        keyboardType="phone-pad"
        value={phoneNumber}
        onChangeText={setPhoneNumber}
      />

      {paymentState === 'error' && <Text style={styles.errorText}>{errorMessage}</Text>}

      {paymentState === 'success' && (
        <Text style={styles.successText}>Payment successful — enjoy SignSense AI!</Text>
      )}

      <TouchableOpacity
        style={styles.payButton}
        onPress={handlePay}
        disabled={paymentState === 'awaitingPhoneApproval'}
      >
        {paymentState === 'awaitingPhoneApproval' ? (
          <>
            <ActivityIndicator color={COLORS.textPrimary} />
            <Text style={styles.payButtonText}>Approve on your phone…</Text>
          </>
        ) : (
          <Text style={styles.payButtonText}>Pay with Lipila</Text>
        )}
      </TouchableOpacity>
    </SafeAreaView>
  );
}

/**
 * Polls Lipila's status endpoint until the collection settles
 * (success or failure), or times out after ~2 minutes — mobile money
 * approval prompts can take a little while for the user to respond to.
 */
async function pollUntilSettled(referenceId: string): Promise<string> {
  const maxAttempts = 24;
  const intervalMs = 5000;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const status = await getCollectionStatus(referenceId);
    const upper = status.toUpperCase();
    if (upper === 'SUCCESSFUL' || upper === 'FAILED' || upper === 'CANCELLED') {
      return status;
    }
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }

  return 'TIMEOUT';
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    padding: 20,
  },
  title: {
    color: COLORS.textPrimary,
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 6,
  },
  subtitle: {
    color: COLORS.textSecondary,
    fontSize: 14,
    marginBottom: 20,
  },
  plansContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 24,
  },
  planCard: {
    flexGrow: 1,
    minWidth: '30%',
    backgroundColor: COLORS.panel,
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  planCardSelected: {
    borderColor: COLORS.accent,
  },
  planLabel: {
    color: COLORS.textSecondary,
    fontSize: 13,
    marginBottom: 4,
  },
  planPrice: {
    color: COLORS.textPrimary,
    fontSize: 18,
    fontWeight: '700',
  },
  inputLabel: {
    color: COLORS.textSecondary,
    fontSize: 13,
    marginBottom: 8,
  },
  input: {
    backgroundColor: COLORS.panel,
    borderRadius: 10,
    padding: 14,
    color: COLORS.textPrimary,
    fontSize: 15,
    marginBottom: 16,
  },
  errorText: {
    color: '#F87171',
    fontSize: 13,
    marginBottom: 12,
    textAlign: 'center',
  },
  successText: {
    color: '#4ADE80',
    fontSize: 14,
    marginBottom: 12,
    textAlign: 'center',
    fontWeight: '600',
  },
  payButton: {
    backgroundColor: COLORS.accent,
    borderRadius: 12,
    paddingVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  payButtonText: {
    color: COLORS.textPrimary,
    fontSize: 16,
    fontWeight: '700',
  },
});
