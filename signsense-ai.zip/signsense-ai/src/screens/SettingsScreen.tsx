import React, { useState } from 'react';
import { SafeAreaView, StyleSheet, Text, View } from 'react-native';
import LanguageSelector from '../components/LanguageSelector';
import type { SupportedLanguage } from '../types';
import { DEFAULT_LANGUAGE, COLORS } from '../config/constants';
import { UI_STRINGS } from '../lib/i18n/translations';

export default function SettingsScreen() {
  const [language, setLanguage] = useState<SupportedLanguage>(DEFAULT_LANGUAGE);

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>{UI_STRINGS[language].settings}</Text>

      <Text style={styles.label}>{UI_STRINGS[language].language}</Text>
      <LanguageSelector selected={language} onSelect={setLanguage} />

      <View style={styles.infoBox}>
        <Text style={styles.infoText}>
          Bluetooth audio output uses your device's default connected
          speaker or headphones automatically — no extra setup needed.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    padding: 16,
  },
  title: {
    color: COLORS.textPrimary,
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 20,
  },
  label: {
    color: COLORS.textSecondary,
    fontSize: 14,
    marginBottom: 8,
  },
  infoBox: {
    marginTop: 24,
    backgroundColor: COLORS.panel,
    borderRadius: 12,
    padding: 16,
  },
  infoText: {
    color: COLORS.textSecondary,
    fontSize: 13,
    lineHeight: 18,
  },
});
