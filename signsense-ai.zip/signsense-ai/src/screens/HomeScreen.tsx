import React, { useState } from 'react';
import { SafeAreaView, StyleSheet, Text, View } from 'react-native';
import CameraView from '../components/CameraView';
import SubtitleDisplay from '../components/SubtitleDisplay';
import LanguageSelector from '../components/LanguageSelector';
import { useHandTracking } from '../hooks/useHandTracking';
import { useSignRecognition } from '../hooks/useSignRecognition';
import { useSentenceBuffer } from '../hooks/useSentenceBuffer';
import { useSentenceSmoothing } from '../hooks/useSentenceSmoothing';
import { useSpeech } from '../hooks/useSpeech';
import type { SupportedLanguage, BufferedSentence } from '../types';
import { DEFAULT_LANGUAGE, COLORS } from '../config/constants';
import { UI_STRINGS } from '../lib/i18n/translations';

export default function HomeScreen() {
  const [language, setLanguage] = useState<SupportedLanguage>(DEFAULT_LANGUAGE);
  const { frameProcessor, latestResult, isModelReady, modelError } = useHandTracking();
  const { prediction } = useSignRecognition(latestResult);
  const { speakSentence } = useSpeech();
  const { process: processSmoothing, offlineNoticeVisible } = useSentenceSmoothing();

  const handleSentenceComplete = async (sentence: BufferedSentence) => {
    // Speak immediately with raw words so output stays hands-free and
    // instant even while smoothing is (maybe) happening in the background.
    if (sentence.words.length <= 1) {
      speakSentence(sentence);
      return;
    }

    const { finalText } = await processSmoothing(sentence);
    speakSentence({ ...sentence, text: finalText });
  };

  const { bufferedText } = useSentenceBuffer(prediction, language, handleSentenceComplete);

  return (
    <SafeAreaView style={styles.container}>
      <LanguageSelector selected={language} onSelect={setLanguage} />

      <View style={styles.cameraContainer}>
        <CameraView frameProcessor={frameProcessor} />
      </View>

      {!isModelReady && !modelError && (
        <View style={styles.offlineNotice}>
          <Text style={styles.offlineNoticeText}>Loading hand-tracking model…</Text>
        </View>
      )}

      {modelError && (
        <View style={styles.offlineNotice}>
          <Text style={styles.offlineNoticeText}>
            Hand-tracking model failed to load — check assets/models/hand_landmark_full.tflite
            is bundled correctly.
          </Text>
        </View>
      )}

      {offlineNoticeVisible && (
        <View style={styles.offlineNotice}>
          <Text style={styles.offlineNoticeText}>
            Sentence smoothing needs internet — speaking raw signs instead.
          </Text>
        </View>
      )}

      <SubtitleDisplay text={bufferedText} placeholder={UI_STRINGS[language].waitingForSign} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  cameraContainer: {
    flex: 1,
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: COLORS.panel,
  },
  offlineNotice: {
    marginHorizontal: 16,
    marginBottom: 8,
    padding: 10,
    borderRadius: 8,
    backgroundColor: '#3A2A0E',
  },
  offlineNoticeText: {
    color: '#F2B84B',
    fontSize: 12,
    textAlign: 'center',
  },
});
