export type PlanId = 'trial' | 'week' | 'twentyDay' | 'month';

export interface SubscriptionPlan {
  id: PlanId;
  label: string;
  durationDays: number;
  priceKwacha: number;
}

/**
 * Pricing in Zambian Kwacha (ZMW), as specified for SignSense AI.
 * "trial" has priceKwacha: 0 and is granted once automatically —
 * it is not something the user pays for via Lipila.
 */
export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  { id: 'trial', label: 'Free trial', durationDays: 3, priceKwacha: 0 },
  { id: 'week', label: '1 week', durationDays: 7, priceKwacha: 50 },
  { id: 'twentyDay', label: '20 days', durationDays: 20, priceKwacha: 100 },
  { id: 'month', label: '1 month', durationDays: 30, priceKwacha: 150 },
];

export function getPlan(id: PlanId): SubscriptionPlan {
  const plan = SUBSCRIPTION_PLANS.find((p) => p.id === id);
  if (!plan) throw new Error(`Unknown plan id: ${id}`);
  return plan;
}
