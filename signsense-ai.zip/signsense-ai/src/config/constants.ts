import type { SupportedLanguage } from '../types';

export const SUPPORTED_LANGUAGES: SupportedLanguage[] = [
  'english',
  'bemba',
  'nyanja',
  'tonga',
  'lozi',
  'kaonde',
  'lunda',
  'luvale',
];

export const DEFAULT_LANGUAGE: SupportedLanguage = 'english';

// How long (ms) with no new recognized sign before we consider
// a sentence "finished" and speak it automatically.
export const SENTENCE_PAUSE_MS = 1500;

// Minimum confidence required to accept a sign prediction.
export const MIN_SIGN_CONFIDENCE = 0.7;

export const COLORS = {
  background: '#0B0F19',
  panel: '#1A2033',
  textPrimary: '#FFFFFF',
  textSecondary: '#9CA3AF',
  textMuted: '#6B7280',
  accent: '#4F7CFF',
};
