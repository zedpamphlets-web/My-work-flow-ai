# SignSense AI

Real-time sign language recognition app: camera → AI recognition → automatic
text → automatic speech → Bluetooth audio output. Built with React Native
(Expo), TypeScript, and on-device ML (MediaPipe / TensorFlow Lite).

## Status

Foundational pipeline is wired end-to-end with a placeholder recognition
model and a 5-word starter vocabulary (hello, thank you, yes, no, help)
across 8 languages: English, Bemba, Nyanja, Tonga, Lozi, Kaonde, Lunda,
Luvale.

## Setup

```bash
npm install
npx expo prebuild
npx expo run:android   # or: npx expo run:ios
```

This project uses native modules (`react-native-vision-camera`,
`react-native-fast-tflite`, `react-native-reanimated`), so it **requires a
custom dev client** — it will not run in the standard Expo Go app.

## AI sentence smoothing (optional, requires internet + API key)

Raw recognized signs come out word-by-word (e.g. "I HELP NEED"), which
doesn't match natural spoken grammar. When online and an API key is
configured, `src/lib/ai/sentenceSmoothing.ts` sends the raw words to an
AI API to produce a natural sentence ("I need help") before it's spoken.

**Setup:** get a free API key (no credit card required) at
https://aistudio.google.com/apikey, then copy `.env.example` to `.env`
and set `EXPO_PUBLIC_AI_API_KEY` to your key. Uses the Gemini API
(`gemini-2.5-flash` model, free tier).

**Offline behavior:** the app still works fully offline. When there's no
internet (or the AI call fails), it speaks the raw word-by-word text
instead and shows a small "smoothing needs internet" notice — nothing
blocks or breaks.

**Security note:** `EXPO_PUBLIC_*` variables get bundled directly into
the app binary, so this setup is fine for development/personal use but
NOT safe for a public release — anyone could extract your key from the
installed app. Before shipping publicly, move this API call behind a
small backend/proxy you control so the real key never ships inside the
app itself.

## Subscription & pricing (Lipila payment gateway)

The app gives every user a **3-day free trial automatically** on first
launch — no login form, no payment info needed (see "Real users via
Firebase" below for how this works without a signup screen). After the
trial (or any paid period) expires, `SubscriptionScreen` is shown
instead of the camera screen, offering three paid plans in Zambian
Kwacha (ZMW), payable via Lipila (Airtel Money, MTN MoMo, Zamtel
Kwacha):

| Plan | Duration | Price |
|---|---|---|
| Free trial | 3 days | Free |
| Weekly | 7 days | K50 |
| 20-day | 20 days | K100 |
| Monthly | 30 days | K150 |

**⚠️ Action needed before this works:** `src/lib/payments/lipilaClient.ts`
has a placeholder base URL. Log into your Lipila dashboard, find the
real sandbox/production REST base URL, and replace
`LIPILA_BASE_URL_SANDBOX` / `LIPILA_BASE_URL_PRODUCTION` in that file.
The request format (reference ID, amount, phone number, ZMW currency)
is already correct per Lipila's official SDK docs — only the base URL
needs confirming.

**Setup:** get your API key from the Lipila dashboard, then set
`EXPO_PUBLIC_LIPILA_API_KEY` in your `.env` file.

**How access tracking works:** trial/subscription status is stored in
Firestore under a real Firebase user (see "Real users via Firebase"
below), with a local on-device cache so the app still works offline.

**Security note:** same as the Gemini key — `EXPO_PUBLIC_*` variables
ship inside the app binary. This is a bigger risk for a *payment* key
specifically. Before any public release, move payment collection
behind your own backend so this key never reaches end users' devices.

## Real users via Firebase (no login screen)

The app uses **Firebase Anonymous Authentication** to give every
person a real, stable Firebase user account — visible in your Firebase
console, queryable in Firestore — without ever showing a signup or
login form. This is what makes trial/subscription tracking (above)
tamper-resistant instead of being purely on-device.

**Setup required in your Firebase console (console.firebase.google.com,
project `interschool-8d764`):**
1. **Authentication → Sign-in method → enable Anonymous**
2. **Firestore Database → Create database** (production mode)
3. Add this security rule so each user can only read/write their own
   record:
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{userId} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
       }
     }
   }
   ```

**Files added:**
- `src/lib/firebase/firebaseConfig.ts` — Firebase init (auth +
  Firestore, with AsyncStorage-backed auth persistence for React
  Native)
- `src/hooks/useAuth.ts` — signs the user in anonymously on first
  launch, exposes their `uid`
- `src/hooks/useSubscription.ts` — now reads/writes trial + paid
  access to Firestore (`users/{uid}`), with local cache fallback when
  offline

**Trade-off to know:** anonymous auth persists across app restarts,
but NOT across a reinstall or a new device (there's no email/password
to "log back in" with). If you want status to survive reinstalls
later, Firebase supports upgrading an anonymous account to a phone
number sign-in without losing its data — a natural next step, not
built yet.

**Note on Analytics:** the Firebase snippet you shared included
`firebase/analytics` — that package only works on web (it needs
browser APIs) and was intentionally left out here. For React Native
analytics, use `@react-native-firebase/analytics` (a separate native
module) or a mobile-friendly analytics tool instead.

## Mandatory sign-up (updated)

The app now requires a real email/password account before use — no
more automatic anonymous access. `AuthScreen` handles both sign-up and
log-in via Firebase Authentication. `App.tsx` gates screens in order:
**not signed in → AuthScreen; signed in but no active trial/plan →
SubscriptionScreen; otherwise → HomeScreen.**

**Setup required in your Firebase console:** Authentication → Sign-in
method → enable **Email/Password** (in addition to, or instead of,
Anonymous — Anonymous is no longer used by the app but you can leave
it enabled or disable it).

## Sign recognition — now genuinely buildable without a native developer

Two things changed here from the previous version:

**1. Hand tracking no longer needs custom native code.** The earlier
approach required hand-writing and compiling custom Kotlin/Swift,
which needs Android Studio/Xcode and can't be verified without a real
device — a real limitation I couldn't get past. This version uses only
**pre-built, already-compiled** libraries instead:
- `react-native-fast-tflite` — runs a `.tflite` model directly inside
  a Vision Camera frame processor, in plain JavaScript
- `vision-camera-resize-plugin` — converts camera frames to the
  model's expected input format (also pre-built, maintained by the
  same author as Vision Camera itself)

Neither requires writing or compiling custom native code — just
`npx expo prebuild` and a build (locally via `expo run:android`, or
in the cloud via `eas build`, which needs no Android Studio/Xcode
installed on your machine at all — see "Building without a local
native toolchain" below).

**Setup required:** download the real hand landmark model Google
publishes and bundle it:
```bash
curl -o assets/models/hand_landmark_full.tflite \
  https://storage.googleapis.com/mediapipe-assets/hand_landmark_full.tflite
```

**⚠️ Honest limitation on tracking accuracy:** a full MediaPipe-quality
pipeline runs a palm *detector* first to crop a tight box around the
hand, then runs the landmark model on that crop. MediaPipe's official
palm detector model uses custom TFLite ops that generic runtimes
(including `react-native-fast-tflite`) cannot load — this is a real,
documented limitation of the open-source model files themselves, not
something fixable in app code. So `useHandTracking.ts` instead resizes
the **center** of the camera frame directly into the landmark model.
This works well when the hand is roughly centered and close to the
camera — which fits this app's use case (holding the phone up while
signing) — but is less robust than a full detector+landmark pipeline
if the hand is off to the side or far away. Framing guidance in the UI
(e.g. "center your hand") would help offset this; not yet built.

**⚠️ Verify before relying on it:** the model's input size is set to
224×224 based on its documented architecture, but you should confirm
the exact tensor shape by opening the downloaded `.tflite` file at
netron.app — if it differs, update `MODEL_INPUT_SIZE` in
`useHandTracking.ts`.

**2. The classifier itself (`src/lib/recognition/model.ts`)** is a
genuinely working geometric classifier — it measures actual hand
landmark geometry (which fingers are extended, via tip-to-wrist vs.
pip-to-wrist distance) to distinguish 5 hand shapes: fist, open palm,
thumbs up, pointing, pinch — mapped onto the 5-word vocabulary.

**Important honesty note, unchanged from before:** these 5 shapes are
simple, distinguishable placeholder poses, **not verified authentic
Zambian Sign Language or ASL handshapes**. Real sign language
recognition needs correct handshapes, movement, and facial/non-manual
markers, trained on real sign-language data — that data doesn't exist
in this project and can't be fabricated here. This classifier is a
legitimate, working stepping stone for testing the full pipeline
end-to-end (camera → real landmarks → real geometry classification →
speech), not a finished sign-language recognizer.

## Building without a local native toolchain

Since neither of us has Android Studio/Xcode, use **EAS Build**
(Expo's free-tier cloud build service) instead — it compiles native
code on Expo's servers:
```bash
npm install -g eas-cli
eas login
eas build --platform android --profile development
```
This produces a real, installable APK you can put on any Android
phone to test — no local native tooling required. (iOS builds work
the same way but installing on a physical iPhone needs an Apple
Developer account; Android is the more accessible path for testing
without one.)

## Still needed before production use

- Bundle the real `hand_landmark_full.tflite` model (see above —
  one download command, not yet done automatically)
- Verify the model's actual input size in Netron and adjust
  `MODEL_INPUT_SIZE` if needed
- Test on a real device via EAS Build and tune `MIN_HAND_PRESENCE_SCORE`
  / the center-crop assumption based on real results
- Real Zambian Sign Language training data, if you want authentic
  handshape recognition rather than the current 5 placeholder poses
- Expanded vocabulary beyond the initial 5 signs
- Native Bluetooth device-name detection (currently a placeholder in
  `src/lib/bluetooth/audioRouting.ts` — TTS already routes to Bluetooth
  automatically via the OS, this only affects the "connected device" UI
  label)
- Native voices/locale packs for Bemba, Nyanja, Tonga, Lozi, Kaonde, Lunda,
  and Luvale (currently fall back to an English voice in
  `src/lib/speech/ttsEngine.ts`, since most devices don't ship dedicated
  TTS voices for these languages yet)

## Project structure

```
src/
├── screens/       HomeScreen, SettingsScreen
├── components/    CameraView, SubtitleDisplay, LanguageSelector
├── hooks/         useCamera, useHandTracking, useSignRecognition,
│                  useSentenceBuffer, useSpeech
├── lib/
│   ├── tracking/    MediaPipe + TFLite hand tracker backends
│   ├── recognition/ Model + vocabulary
│   ├── speech/      TTS engine wrapper
│   ├── bluetooth/   Audio routing status
│   └── i18n/        UI string translations
├── types/
└── config/
```
